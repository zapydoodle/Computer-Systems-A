package stubs

var ReverseHandler = "SecretStringOperations.Reverse"
var PremiumReverseHandler = "SecretStringOperations.FastReverse"


type Response struct {
	Message string
}

type Request struct {
	Message string
}


